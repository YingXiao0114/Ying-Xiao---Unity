﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BonceyBall : MonoBehaviour {

	public GameObject target;
	public Vector3 velocity;
	public AudioSource sfx;
	public float speed;
	public Material[] materials;

	private Renderer rend;
	private Vector3 acceleration; //this will be a -y movement.
	private bool collide;
	private int count = 0;

	// Use this for initialization
	void Start () {
		//velocity = new Vector3 (0f, 0.1f, 0f);
		//velocity = Random.insideUnitSphere;
		velocity = new Vector3 (Random.Range(-1f,1f), 0f, Random.Range(-.1f, 1f));
		acceleration = new Vector3 (0f, -.98f, 0f);

		rend = GetComponent <Renderer>();
		rend.sharedMaterial = materials[0];
		collide = false;
	}
	
	// Update is called once per frame
	void Update ()
	{
		this.transform.position += velocity;
		velocity *= speed;
		boundsCheck (this.transform.position, target.GetComponent <Bounds> ().walls, this.transform.localScale);
		if (collide) {
			count ++;
			print (count);
			rend.sharedMaterial = materials [count];
			if (count == 5) {
				count = 0;
			}
			collide = false;
		};
		//acceleration = new Vector3 (0f, -.98f, 0f);

		gravitationalMovement ();


	}

	void boundsCheck (Vector3 checkFrom, Vector3 checkAgainst, Vector3 size){
		//if this x > box.bounds.rightWall
		// x = x * -1
		// if this x < box.bounds.leftWall
		// x = x * -1
		if (checkFrom.x + size.x / 2f >= checkAgainst.x / 2f) {
			velocity.x *= -1f;
			sfx.Play();

			collide = true;

			print ("I HIT A WALL!!!!");
		}
		if (checkFrom.x - size.x / 2f <= -checkAgainst.x / 2f) {
			velocity.x *= -1f;

			collide = true;
			print ("I HIT A WALL!!!!");
		}

		//y
		if (checkFrom.y + size.y / 2f >= checkAgainst.y / 2f) {
			velocity.y *= -1f;

			collide = true;
			print ("I HIT A WALL!!!!");
		}

		if (checkFrom.y - size.y / 2f <= -checkAgainst.y / 2f) {
			velocity.y *= -1f;

			collide = true;
			print ("I HIT A WALL!!!!");
		}

		//z
		if (checkFrom.z + size.z / 2f >= checkAgainst.z / 2f) {
			velocity.z *= -1f;

			collide = true;
			print ("I HIT A WALL!!!!");
		}

		if (checkFrom.z - size.z / 2f <= -checkAgainst.z / 2f) {
			velocity.z *= -1f;

			collide = true;
			print ("I HIT A WALL!!!!");
		}
	}

	void gravitationalMovement (){
		// kinematic : vel = preVel + accel * time;
		velocity = velocity + acceleration * Time.deltaTime; //
		print (velocity.y);
	}

	void OnCollisionEnter (Collision col)
	{
		print (col.collider.name);
	}
}